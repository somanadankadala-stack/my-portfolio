# Somanad | Portfolio

A single-page personal portfolio built with HTML, CSS and JavaScript.

## Sections
- Home, with an interactive skill gap check
- About
- Skills (JavaScript, CSS, HTML, Python)
- Contact

## Run locally
Open `index.html` in any browser. No build step needed.

## Deploy with GitHub Pages
1. Push this repository to GitHub.
2. Go to Settings > Pages.
3. Under Source, choose the `main` branch and the `/ (root)` folder, then save.
4. Your site goes live at `https://<your-username>.github.io/<repository-name>/`.
